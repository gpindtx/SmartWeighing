#!bin/bash
partitions=10
json_path="data/weighings/treated/weighings_treated.json"
file_path="data/weighings/weighings.json"
collection="weighings"

while [ "$1" != "" ]; do
    case $1 in
        -p | --partitions )     shift
                                partitions=$1
                                ;;
        -c | --collection )     shift
                                collection=$1
                                file_path="data/$collection/${collection}.json"
                                json_path="data/$collection/treated/${collection}_treated.json"
                                ;;
        -j | --json_path )      shift
                                json_path=$1
                                ;;
        -f | --file_path )      shift
                                file_path=$1
                                ;;
        * )                     exit 1
    esac
    shift
done

for i in $(seq 1 $partitions); do
    node index.js to_json --partition $i --json_path $json_path --file_path $file_path --collection $collection;
done

