const mongoose = require('mongoose');
const weighing_service = require('./services/weighings');
const diagnosticdatas_service = require('./services/diagnosticdatas');
const devices_service = require('./services/devices');
const devicesinfos_service = require('./services/devicesinfos')
const alarms_service = require('./services/alarms');
const fs = require('fs');

db_connect = async (url) => {
    await mongoose.connect(url, {useNewUrlParser: true, useUnifiedTopology: true})
}

withdrawPartition = async (collection, lower_index, upper_index) => {
    let data = []
    switch(collection) {
        case "weighings":
            data = await weighing_service.getPartition(lower_index, upper_index);
            break;
        case "devices":
            data = await devices_service.getPartition(lower_index, upper_index);
            break;
        case "devicesinfos":
            data = await devicesinfos_service.getPartition(lower_index, upper_index);
            break;
        case "alarms":
            data = await alarms_service.getPartition(lower_index, upper_index);
            break;
        case "diagnosticdatas":
            data = await diagnosticdatas_service.getPartition(lower_index, upper_index);
            break;
        default:
            console.log("Unrecognized collection: " + collection);
    }
    return data;
}

writePartition = async (file_path, retrieve_partition, dados) => {
    path_parts = file_path.split('.')
    file_name = path_parts[0];
    terminator = path_parts[1];
    path = file_name + '_partition' + retrieve_partition + "." + terminator
    await initializeFile(path);
    file_data = fs.readFileSync(path);
    file_data = JSON.parse(file_data);
    file_data = file_data.concat(dados, undefined, 4);
    fs.writeFileSync(path, JSON.stringify(file_data, null, 4));
}

initializeFile = async (file_path) => {
    if(!fs.existsSync(file_path)) {
        file_data = []
        fs.writeFileSync(file_path, JSON.stringify(file_data, null, 4));
    }
}

sizeSplit = async (total_size, partitions) => {
    block_size = Math.ceil(total_size/partitions);
    indexes = []
    for(i=0, current_index=0; i<partitions;i++, current_index += block_size) {
        new_index = [current_index, block_size]
        indexes.push(new_index)
    }
    return indexes;
}

collectionConfig = async (size, partitions, url) => {
    if(size < 65000) {
        indexes = [[0,size]];
        partitions=1;
    } else {
        indexes = await sizeSplit(size, partitions)
    }

    return {
        size: size,
        indexes: indexes,
        partitions: partitions,
        url: url
    }
    
}

initConfig = async (
    size = undefined,
    partitions = 10,
    url="mongodb+srv://nunoleite:82QymHwOUd0jO5Yo@iot-production-jywab.mongodb.net/iot-production?retryWrites=true&w=majority"
) => {
    fs.mkdirSync('data/weighings');
    fs.mkdirSync('data/devices');
    fs.mkdirSync('data/devicesinfos');
    fs.mkdirSync('data/alarms');
    fs.mkdirSync('data/diagnosticdatas');
    fs.mkdirSync('data/weighings/treated');
    fs.mkdirSync('data/devices/treated');
    fs.mkdirSync('data/devicesinfos/treated');
    fs.mkdirSync('data/alarms/treated');
    fs.mkdirSync('data/diagnosticdatas/treated');
    await db_connect(url);
    weighings_size = await weighing_service.count();
    diagnosticdatas_size = await diagnosticdatas_service.count();
    devices_size = await devices_service.count();
    devicesinfos_size = await devicesinfos_service.count();
    alarms_size = await alarms_service.count();
    config = {
        "weighings": undefined,
        "devices": undefined,
        "devicesinfos": undefined,
        "diagnosticdatas": undefined,
        "alarms": undefined
    }
    config["weighings"] = await collectionConfig(weighings_size, partitions, url);
    config["devices"] = await collectionConfig(devices_size, partitions, url);
    config["devicesinfos"] = await collectionConfig(devicesinfos_size, partitions, url);
    config["diagnosticdatas"] = await collectionConfig(diagnosticdatas_size, partitions, url);
    config["alarms"] = await collectionConfig(alarms_size, partitions, url);
    fs.writeFileSync('config.json', JSON.stringify(config, undefined, 4));
}

readConfig = async () => {
    config_str = fs.readFileSync('config.json');
    config = JSON.parse(config_str);
    return config;
}

extractData = async (
    retrieve_partition=undefined,
    collection="weighings",
    file_path="data/weighings/weighings.json",
    url="mongodb+srv://nunoleite:82QymHwOUd0jO5Yo@iot-production-jywab.mongodb.net/iot-production?retryWrites=true&w=majority"
) => {
    await db_connect(url);
    if (!fs.existsSync('config.json')) {
        console.log("Please initialize the Extractor. Run `node index.js init` or check `node index.js --help` for help.")
        process.exit(0)
    } else {
        config = await readConfig();
        indexes = config[collection]["indexes"];
        if(retrieve_partition != undefined) {
            if(retrieve_partition > config[collection]["partitions"]) {
                console.log("No partition to extract.");
                process.exit(0);
            }
            file_path = "data/" + collection + "/" + collection + ".json"
            index = indexes[retrieve_partition-1];
            console.log("Extracting partition " + retrieve_partition + ": From record " + index[0] + " to record " + (index[0] + index[1]));
            const data = await withdrawPartition(collection, index[0], index[1]);
            await writePartition(file_path, retrieve_partition, data);
        } else {
            console.log("--retrieve_partition option must be specified.")
            process.exit(0)
        }   
    }
}

treatTerminalSoftware = (software_array, data) => {
    i = 0
    for(value of software_array) {
        if(i<4) {
            terminalSoftwareId = "terminalSoftwareId_" + i
            data[terminalSoftwareId].push(value)
            i++
        }   
    }
    if(i <= 3) {
        for(j=i; j<=3;j++) {
            terminalSoftwareId = "terminalSoftwareId_" + j
            data[terminalSoftwareId].push(null)
        }
    }

    return data;
}

treatCellsDevicesInfos = (cells_array, data) => {
    i = 0
    treated = false
    for(cell of cells_array) {
        if(i<8) {
            cellSerialNumber = "cell" + i + "_serialNumber"
            cellId = "cell" + i + "_id"
            cellType = "cell" + i + "_type"
            cellSoftwareId = "cell" + i + "_softwareId"
            cellAngularCoefficient = "cell" + i + "_angularCoefficient"
            cellText = "cell" + i + "_text"
            if(cell["cellSerialNumber"]) {
                data[cellSerialNumber].push(cell["cellSerialNumber"])
            } else {
                data[cellSerialNumber].push(null)
            }
            if(cell["cellId"]) {
                data[cellId].push(cell["cellId"])
            } else {
                data[cellId].push(null)
            }
            if(cell["cellType"]) {
                data[cellType].push(cell["cellType"])
            } else {
                data[cellType].push(null)
            }
            if(cell["cellSoftwareId"]) {
                data[cellSoftwareId].push(cell["cellSoftwareId"])
            } else {
                data[cellSoftwareId].push(null)
            }
            if(cell["cellAngularCoefficient"]) {
                data[cellAngularCoefficient].push(cell["cellAngularCoefficient"])
            } else {
                data[cellAngularCoefficient].push(null)
            }
            if(cell["cellText"]) {
                data[cellText].push(cell["cellText"])
            } else {
                data[cellText].push(null)
            }
            i++
            treated=true
        }

    }

    if(i <= 7) {
        for(j=i; j<=7;j++) {
            cellSerialNumber = "cell" + j + "_serialNumber"
            cellId = "cell" + j + "_id"
            cellType = "cell" + j + "_type"
            cellSoftwareId = "cell" + j + "_softwareId"
            cellAngularCoefficient = "cell" + j + "_angularCoefficient"
            cellText = "cell" + j + "_text"
            data[cellSerialNumber].push(null)
            data[cellId].push(null)
            data[cellType].push(null)
            data[cellSoftwareId].push(null)
            data[cellAngularCoefficient].push(null)
            data[cellText].push(null)
        }
    }

    return data;
}

treatCellsDiagnosticDatas = (cells_array, data) => {
    i = 0
    treated = false
    for(cell of cells_array) {
        if(i < 8) {
            cellSerialNumber = "cell" + i + "_serialNumber"
            cellPowerSupply = "cell" + i + "_powerSupply"
            cellTemperature = "cell" + i + "_temperature"
            cellInternalVolt = "cell" + i + "_internalVolt"
            cellDeadloadCount = "cell" + i + "_deadloadCount"
            if(cell["cellSerialNumber"]) {
                data[cellSerialNumber].push(cell["cellSerialNumber"])
            } else {
                data[cellSerialNumber].push(null)
            }
            if(cell["cellPowerSupply"]) {
                data[cellPowerSupply].push(cell["cellPowerSupply"])
            } else {
                data[cellPowerSupply].push(null)
            }
            if(cell["cellTemperature"]) {
                data[cellTemperature].push(cell["cellTemperature"])
            } else {
                data[cellTemperature].push(null)
            }
            if(cell["cellInternalVolt"]) {
                data[cellInternalVolt].push(cell["cellInternalVolt"])
            } else {
                data[cellInternalVolt].push(null)
            }
            if(cell["cellDeadloadCount"]) {
                data[cellDeadloadCount].push(cell["cellDeadloadCount"])
            } else {
                data[cellDeadloadCount].push(null)
            }
            i++
            treated=true
            }
    }

    if(i <= 7) {
        for(j=i; j<=7;j++) {
            cellSerialNumber = "cell" + j + "_serialNumber"
            cellPowerSupply = "cell" + j + "_powerSupply"
            cellTemperature = "cell" + j + "_temperature"
            cellInternalVolt = "cell" + j + "_internalVolt"
            cellDeadloadCount = "cell" + j + "_deadloadCount"
            data[cellSerialNumber].push(null)
            data[cellPowerSupply].push(null)
            data[cellTemperature].push(null)
            data[cellInternalVolt].push(null)
            data[cellDeadloadCount].push(null)
        }
    }

    return data;

}

treatCellsWeighings = (cells_array, data) => {
    i = 0
    treated = false
    for (cell of cells_array) {
        if(i<8) {
            treated = false
            id_string = "cellId_" + i
            sn_string = "cellSerialNumber_" + i
            weight_string = "cellWeight_" + i
            if(cell["_id"]) {
                data[id_string].push(cell["_id"])
            } else {
                data[id_string].push(null)
            }
            if(cell["cellSerialNumber"]) {
                data[sn_string].push(cell["cellSerialNumber"])
            } else {
                data[sn_string].push(null)
            }
            if(Object.keys(cell).includes("cellWeight")) {
                data[weight_string].push(cell["cellWeight"])
            } else {
                data[weight_string].push(null)
            }
            i++
            treated=true
        }
        
    }

    if(i <= 7) {
        for(j=i; j<=7;j++) {
            id_string = "cellId_" + j
            sn_string = "cellSerialNumber_" + j
            weight_string = "cellWeight_" + j
            data[id_string].push(null)
            data[sn_string].push(null)
            data[weight_string].push(null)
        }
    }

    return data;

}

toJSONWeighings = async (
    partition = undefined,
    file_path="data/weighings/weighings.json",
    json_path="data/weighings/weighings_treated.json" 
) => {
    path_parts = file_path.split('.')
    json_path_parts = json_path.split('.')
    file_name = path_parts[0]
    terminator = path_parts[1]
    path = file_name + "_partition" + partition + "." + terminator
    path_to_write = json_path_parts[0] + "_partition" + partition + "." + json_path_parts[1]
    weighings_str = fs.readFileSync(path)
    weighings = JSON.parse(weighings_str)
    data_dict = {
        "_id": [],
        "timestamp": [],
        "terminalSerialNumber": [],
        "scaleSerialNumber": [],
        "scaleGross": [],
        "scaleNet": [],
        "cellId_0": [],
        "cellSerialNumber_0": [],
        "cellWeight_0": [],
        "cellId_1": [],
        "cellSerialNumber_1": [],
        "cellWeight_1": [],
        "cellId_2": [],
        "cellSerialNumber_2": [],
        "cellWeight_2": [],
        "cellId_3": [],
        "cellSerialNumber_3": [],
        "cellWeight_3": [],
        "cellId_4": [],
        "cellSerialNumber_4": [],
        "cellWeight_4": [],
        "cellId_5": [],
        "cellSerialNumber_5": [],
        "cellWeight_5": [],
        "cellId_6": [],
        "cellSerialNumber_6": [],
        "cellWeight_6": [],
        "cellId_7": [],
        "cellSerialNumber_7": [],
        "cellWeight_7": []
    }

    for (weighing of weighings) {
        if(!Number.isInteger(weighing) && weighing != null) {
            if(weighing["_id"]) {
                data_dict["_id"].push(weighing["_id"])
            } else {
                data_dict["_id"].push(null) 
            }

            if(weighing["timestamp"]) {
                data_dict["timestamp"].push(weighing["timestamp"])
            } else {
                data_dict["timestamp"].push(null) 
            }

            if(weighing["terminalSerialNumber"]) {
                data_dict["terminalSerialNumber"].push(weighing["terminalSerialNumber"])
            } else {
                data_dict["terminalSerialNumber"].push(null) 
            }

            if(weighing["scaleSerialNumber"]) {
                data_dict["scaleSerialNumber"].push(weighing["scaleSerialNumber"])
            } else {
                data_dict["scaleSerialNumber"].push(null) 
            }

            if(Object.keys(weighing).includes("scaleGross")) {
                data_dict["scaleGross"].push(weighing["scaleGross"])
            } else {
                data_dict["scaleGross"].push(null) 
            }

            if(Object.keys(weighing).includes("scaleNet")) {
                data_dict["scaleNet"].push(weighing["scaleNet"])
            } else {
                data_dict["scaleNet"].push(null) 
            }

            if(weighing["cellsArray"] != undefined) {
                data_dict = treatCellsWeighings(weighing["cellsArray"], data_dict)
            } else {
                data_dict = treatCellsWeighings([], data_dict)
            }
        }
    }
    fs.writeFileSync(path_to_write, JSON.stringify(data_dict, undefined, 4))
}

toJSONDevices = async (
    partition,
    file_path,
    json_path
) => {
    path_parts = file_path.split('.')
    json_path_parts = json_path.split('.')
    file_name = path_parts[0]
    terminator = path_parts[1]
    path = file_name + "_partition" + partition + "." + terminator
    path_to_write = json_path_parts[0] + "_partition" + partition + "." + json_path_parts[1]
    try {
        devices_str = fs.readFileSync(path)
    } catch(Exception) {
        console.log("Partition not found.")
        process.exit(0);
    }
    devices = JSON.parse(devices_str)
    data_dict = {
        "_id": [],
        "name": [],
        "serialNumber": [],
        "terminalModel": [],
        "geoLat": [],
        "geoLng": [],
        "terminalSerialNumber": [],
        "dimensions": [],
        "maxCapacity": [],
        "divisionSize": [],
        "dealerCompany": [],
        "subsidiaryCompany": [],
        "customerCompany": []
    }

    for(elem of devices) {
        if(!Number.isInteger(elem) && elem != null) {
            if(elem["_id"]) {
                data_dict["_id"].push(elem["_id"])
            } else {
                data_dict["_id"].push(null) 
            }

            if(elem["name"]) {
                data_dict["name"].push(elem["name"])
            } else {
                data_dict["name"].push(null) 
            }

            if(elem["serialNumber"]) {
                data_dict["serialNumber"].push(elem["serialNumber"])
            } else {
                data_dict["serialNumber"].push(null) 
            }

            if(elem["terminalModel"]) {
                data_dict["terminalModel"].push(elem["terminalModel"])
            } else {
                data_dict["terminalModel"].push(null) 
            }

            if(elem["geoLat"]) {
                data_dict["geoLat"].push(elem["geoLat"])
            } else {
                data_dict["geoLat"].push(null) 
            }

            if(elem["geoLng"]) {
                data_dict["geoLng"].push(elem["geoLng"])
            } else {
                data_dict["geoLng"].push(null) 
            }

            if(elem["terminalSerialNumber"]) {
                data_dict["terminalSerialNumber"].push(elem["terminalSerialNumber"])
            } else {
                data_dict["terminalSerialNumber"].push(null) 
            }

            if(elem["dimensions"]) {
                data_dict["dimensions"].push(elem["dimensions"])
            } else {
                data_dict["dimensions"].push(null) 
            }

            if(elem["maxCapacity"]) {
                data_dict["maxCapacity"].push(elem["maxCapacity"])
            } else {
                data_dict["maxCapacity"].push(null) 
            }

            if(elem["divisionSize"]) {
                data_dict["divisionSize"].push(elem["divisionSize"])
            } else {
                data_dict["divisionSize"].push(null) 
            }

            if(elem["dealerCompany"]) {
                data_dict["dealerCompany"].push(elem["dealerCompany"])
            } else {
                data_dict["dealerCompany"].push(null) 
            }

            if(elem["subsidiaryCompany"]) {
                data_dict["subsidiaryCompany"].push(elem["subsidiaryCompany"])
            } else {
                data_dict["subsidiaryCompany"].push(null) 
            }

            if(elem["customerCompany"]) {
                data_dict["customerCompany"].push(elem["customerCompany"])
            } else {
                data_dict["customerCompany"].push(null) 
            }
        }
    }
    fs.writeFileSync(path_to_write, JSON.stringify(data_dict, undefined, 4))
    
}

toJSONDevicesInfos = async (
    partition,
    file_path,
    json_path
) => {
    path_parts = file_path.split('.')
    json_path_parts = json_path.split('.')
    file_name = path_parts[0]
    terminator = path_parts[1]
    path = file_name + "_partition" + partition + "." + terminator
    path_to_write = json_path_parts[0] + "_partition" + partition + "." + json_path_parts[1]
    try {
        devicesinfos_str = fs.readFileSync(path)
    } catch(Exception) {
        console.log("Partition not found.")
        process.exit(0);
    }
    devicesinfos = JSON.parse(devicesinfos_str)
    data_dict = {
        "_id": [],
        "scaleSerialNumber": [],
        "terminalSerialNumber": [],
        "scaleCellCount": [],
        "scaleDataAvailability": [],
        "scaleId": [],
        "scaleSoftwareId": [],
        "scaleText": [],
        "scaleType": [],
        "terminalText": [],
        "terminalType": [],
        "timestamp": []
    }
    for(let i = 0; i < 8; i++) {
        cellSerialNumber = "cell" + i + "_serialNumber"
        cellId = "cell" + i + "_id"
        cellType = "cell" + i + "_type"
        cellSoftwareId = "cell" + i + "_softwareId"
        cellAngularCoefficient = "cell" + i + "_angularCoefficient"
        cellText = "cell" + i + "_text"
        if(i<4) {
            terminalSoftwareId = "terminalSoftwareId_" + i
            data_dict[terminalSoftwareId] = []
        }
        data_dict[cellSerialNumber] = []
        data_dict[cellId] = []
        data_dict[cellType] = []
        data_dict[cellSoftwareId] = []
        data_dict[cellAngularCoefficient] = []
        data_dict[cellText] = []
    }

    for(elem of devicesinfos) {
        if(!Number.isInteger(elem) && elem != null) {
            if(elem["_id"]) {
                data_dict["_id"].push(elem["_id"])
            } else {
                data_dict["_id"].push(null) 
            }

            if(elem["timestamp"]) {
                data_dict["timestamp"].push(elem["timestamp"])
            } else {
                data_dict["timestamp"].push(null) 
            }

            if(elem["scaleSerialNumber"]) {
                data_dict["scaleSerialNumber"].push(elem["scaleSerialNumber"])
            } else {
                data_dict["scaleSerialNumber"].push(null) 
            }

            if(elem["terminalSerialNumber"]) {
                data_dict["terminalSerialNumber"].push(elem["terminalSerialNumber"])
            } else {
                data_dict["terminalSerialNumber"].push(null) 
            }

            if(elem["scaleCellCount"]) {
                data_dict["scaleCellCount"].push(elem["scaleCellCount"])
            } else {
                data_dict["scaleCellCount"].push(null) 
            }

            if(elem["scaleDataAvailability"]) {
                data_dict["scaleDataAvailability"].push(elem["scaleDataAvailability"])
            } else {
                data_dict["scaleDataAvailability"].push(null) 
            }

            if(elem["scaleId"]) {
                data_dict["scaleId"].push(elem["scaleId"])
            } else {
                data_dict["scaleId"].push(null) 
            }

            if(elem["scaleSoftwareId"]) {
                data_dict["scaleSoftwareId"].push(elem["scaleSoftwareId"])
            } else {
                data_dict["scaleSoftwareId"].push(null) 
            }

            if(elem["scaleText"]) {
                data_dict["scaleText"].push(elem["scaleText"])
            } else {
                data_dict["scaleText"].push(null) 
            }

            if(elem["scaleType"]) {
                data_dict["scaleType"].push(elem["scaleType"])
            } else {
                data_dict["scaleType"].push(null) 
            }

            if(elem["terminalText"]) {
                data_dict["terminalText"].push(elem["terminalText"])
            } else {
                data_dict["terminalText"].push(null) 
            }

            if(elem["terminalType"]) {
                data_dict["terminalType"].push(elem["terminalType"])
            } else {
                data_dict["terminalType"].push(null) 
            }

            if(elem["cells"]) {
                data_dict = treatCellsDevicesInfos(elem["cells"], data_dict)
            } else {
                data_dict = treatCellsDevicesInfos([], data_dict) 
            }

            if(elem["terminalSoftwareId"]) {
                data_dict = treatTerminalSoftware(elem["terminalSoftwareId"], data_dict)
            } else {
                data_dict = treatTerminalSoftware([], data_dict) 
            }
        }
    }
    fs.writeFileSync(path_to_write, JSON.stringify(data_dict, undefined, 4))
}

toJSONDiagnosticDatas = async (
    partition,
    file_path,
    json_path
) => {
    path_parts = file_path.split('.')
    json_path_parts = json_path.split('.')
    file_name = path_parts[0]
    terminator = path_parts[1]
    path = file_name + "_partition" + partition + "." + terminator
    path_to_write = json_path_parts[0] + "_partition" + partition + "." + json_path_parts[1]
    try {
        diagnosticdatas_str = fs.readFileSync(path)
    } catch(Exception) {
        console.log("Partition not found.")
        process.exit(0);
    }
    diagnosticdatas = JSON.parse(diagnosticdatas_str)
    data_dict = {
        "_id": [],
        "scaleSerialNumber": [],
        "terminalSerialNumber": [],
        "timestamp": []
    }
    for(let i = 0; i < 8; i++) {
        cellSerialNumber = "cell" + i + "_serialNumber"
        cellPowerSupply = "cell" + i + "_powerSupply"
        cellTemperature = "cell" + i + "_temperature"
        cellInternalVolt = "cell" + i + "_internalVolt"
        cellDeadloadCount = "cell" + i + "_deadloadCount"
        data_dict[cellSerialNumber] = []
        data_dict[cellPowerSupply] = []
        data_dict[cellTemperature] = []
        data_dict[cellInternalVolt] = []
        data_dict[cellDeadloadCount] = []
    }

    for(elem of diagnosticdatas) {
        if(!Number.isInteger(elem) && elem != null) {
            if(elem["_id"]) {
                data_dict["_id"].push(elem["_id"])
            } else {
                data_dict["_id"].push(null) 
            }

            if(elem["timestamp"]) {
                data_dict["timestamp"].push(elem["timestamp"])
            } else {
                data_dict["timestamp"].push(null) 
            }

            if(elem["scaleSerialNumber"]) {
                data_dict["scaleSerialNumber"].push(elem["scaleSerialNumber"])
            } else {
                data_dict["scaleSerialNumber"].push(null) 
            }

            if(elem["terminalSerialNumber"]) {
                data_dict["terminalSerialNumber"].push(elem["terminalSerialNumber"])
            } else {
                data_dict["terminalSerialNumber"].push(null) 
            }

            if(elem["cellsArray"]) {
                data_dict = treatCellsDiagnosticDatas(elem["cellsArray"], data_dict)
            } else {
                data_dict = treatCellsDiagnosticDatas([], data_dict) 
            }
        }
    }
    fs.writeFileSync(path_to_write, JSON.stringify(data_dict, undefined, 4))
}

toJSONAlarms = async (
    partition,
    file_path,
    json_path
) => {
    path_parts = file_path.split('.')
    json_path_parts = json_path.split('.')
    file_name = path_parts[0]
    terminator = path_parts[1]
    path = file_name + "_partition" + partition + "." + terminator
    path_to_write = json_path_parts[0] + "_partition" + partition + "." + json_path_parts[1]
    try {
        alarms_str = fs.readFileSync(path)
    } catch(Exception) {
        console.log("Partition not found.")
        process.exit(0);
    }
    alarms = JSON.parse(alarms_str)
    data_dict = {
        "_id": [],
        "serialNumber": [],
        "counter": [],
        "errorContext": [],
        "errorCode": [],
        "errorInfo": [],
        "status": [],
        "timestamp": []
    }

    for(elem of alarms) {
        if(!Number.isInteger(elem) && elem != null) {
            if(elem["_id"]) {
                data_dict["_id"].push(elem["_id"])
            } else {
                data_dict["_id"].push(null) 
            }

            if(elem["timestamp"]) {
                data_dict["timestamp"].push(elem["timestamp"])
            } else {
                data_dict["timestamp"].push(null) 
            }

            if(elem["serialNumber"]) {
                data_dict["serialNumber"].push(elem["serialNumber"])
            } else {
                data_dict["serialNumber"].push(null) 
            }

            if(elem["counter"]) {
                data_dict["counter"].push(elem["counter"])
            } else {
                data_dict["counter"].push(null) 
            }

            if(elem["errorContext"]) {
                data_dict["errorContext"].push(elem["errorContext"])
            } else {
                data_dict["errorContext"].push(null) 
            }

            if(elem["errorCode"]) {
                data_dict["errorCode"].push(elem["errorCode"])
            } else {
                data_dict["errorCode"].push(null) 
            }

            if(elem["errorInfo"]) {
                data_dict["errorInfo"].push(elem["errorInfo"])
            } else {
                data_dict["errorInfo"].push(null) 
            }

            if(elem["status"]) {
                data_dict["status"].push(elem["status"])
            } else {
                data_dict["status"].push(null) 
            }
        }
    }
    fs.writeFileSync(path_to_write, JSON.stringify(data_dict, undefined, 4))
}

toJSON = async (
    partition = undefined,
    collection="weighings",
    file_path="data/weighings/weighings.json",
    json_path="data/weighings/treated/weighings_treated.json"
) => {
    file_path = "data/" + collection + "/" + collection + ".json"
    json_path = "data/" + collection + "/treated/" + collection + ".json"
    switch(collection) {
        case "weighings":
            await toJSONWeighings(partition, file_path, json_path);
            break;
        case "devices":
            await toJSONDevices(partition, file_path, json_path);
            break;
        case "devicesinfos":
            await toJSONDevicesInfos(partition, file_path, json_path);
            break;
        case "diagnosticdatas":
            await toJSONDiagnosticDatas(partition, file_path, json_path);
            break;
        case "alarms":
            await toJSONAlarms(partition, file_path, json_path);
            break;
        default:
            console.log("Collection not recognized");
            process.exit(0);
    }
    
}

printHelp = () => {
    console.log("This script allows the execution of three commands:");
    console.log("   - `init`. The first command to execute. Mandatory!")
    console.log("   - 'extract'. Extracts the data from the weighings collection depending on options passed.");
    console.log("   - 'to_json'. Converts a partition into pandas/dask readable json file.")
    console.log("\n")
    console.log("init command:");
    console.log("       --partitions The number of partitions to split the data. Facilitates extraction. Defaults to 10");
    console.log("       --size The number of records to read. If it is not specified, all available records are read.");
    console.log("       --url The url to use for extraction. Assumes the default used for access to Bilaniciai's DB.");
    console.log("\n")
    console.log("extract command:");
    console.log("   Simple usage: node index.js extract");
    console.log("   Options:");
    console.log("       --retrieve_partition The number of the partition to retrieve. Mandatory.")
    console.log("       --file_path By passing this option you may state where you want to store the JSON data. Include the terminator .json. Defaults to weighings.json in the current directory")
    console.log("       --collection Specifies the collection to extract.")
    console.log("\n\n");
    console.log("to_json command:");
    console.log("   Simple usage: node index.js to_csv");
    console.log("   Options:");
    console.log("       --partition The partition number that should be converted to csv")
    console.log("       --file_path The file where the JSON data is stored. Defaults to weighings.json in the current directory");
    console.log("       --json_path The path where you wish to store the JSON file. Defaults to weighings_partition_<number>.json in the current directory.");
    console.log("       --collection Specifies the collection to transform")
}

parseInitArgs = args => {
    let isOption = false;
    let option = "";
    let parsed_args = {};
    for (arg of args) {
        if(['--size', '--partitions', '--url'].includes(arg)) {
            if(isOption) {
                console.log("malformed command. Two options in a row without values.");
                break;
            }
            isOption = true;
            option = arg.split("--")[1];
            parsed_args[option] = undefined;
        } else if(isOption) {
            if(option === 'size' || option === 'partitions') {
                arg = parseInt(arg);
                if(Number.isNaN(arg)) {
                    console.log("The option " + option + " has to be an integer.");
                }  
            }
            parsed_args[option] = arg;
            isOption = false;
        } else {
            console.log("Unrecognized option: " + arg + ".");
            break
        }
    }

    return parsed_args;
}


parseExtractArgs = args => {
    let isOption = false;
    let option = "";
    let parsed_args = {};
    for (arg of args) { 
        if(['--file_path', '--retrieve_partition', '--collection'].includes(arg)) {
            if(isOption) {
                console.log("malformed command. Two options in a row without values.");
                break;
            }
            isOption = true;
            option = arg.split("--")[1];
            parsed_args[option] = undefined;
        } else if(isOption) {
            if(option === 'retrieve_partition') {
                arg = parseInt(arg);
                if(Number.isNaN(arg)) {
                    console.log("The option " + option + " has to be an integer.");
                }  
            }
            parsed_args[option] = arg;
            isOption = false;
        } else {
            console.log("Unrecognized option: " + arg + ".");
            break
        }
    }

    return parsed_args;
}

parseToJSONArgs = args => {
    let isOption = false;
    let option = "";
    let parsed_args = {};
    for (arg of args) {
        if(['--partition', '--file_path', '--json_path', '--collection'].includes(arg)) {
            if(isOption) {
                console.log("malformed command. Two options in a row without values.");
                break;
            }
            isOption = true;
            option = arg.split("--")[1];
            parsed_args[option] = undefined;
        } else if(isOption) {
            parsed_args[option] = arg;
            isOption = false;
        } else {
            console.log("Unrecognized option: " + arg + ".");
            break
        }
    }

    return parsed_args;
}

async function main() {
    args = process.argv
    command = args[2];
    if (command == undefined) {
        console.log("A command must be issued. Issue 'node index.js --help' for more information.")
    } else if(command === "--help") {
        printHelp()
    } else if(command == 'init') {
        args = process.argv.slice(3)
        parsed_args = parseInitArgs(args);
        await initConfig(parsed_args.size, parsed_args.partitions, parsed_args.url)
        console.log('Configuration file initialized')
    } else if (command == 'extract') {
        args = process.argv.slice(3)
        parsed_args = parseExtractArgs(args)
        await extractData(parsed_args.retrieve_partition, parsed_args.collection, parsed_args.file_path, parsed_args.url)
        console.log('Data extracted to the specified file path.')
    } else if(command == 'to_json') {
        args = process.argv.slice(3)
        parsed_args = parseToJSONArgs(args)
        await toJSON(parsed_args.partition, parsed_args.collection, parsed_args.file_path, parsed_args.json_path)
        console.log('Data refactored to a pandas/dask easily recognizable format.')
    } else {
        console.log('Unrecognized command issued.')
    }
}

  main()
    .then(() => {
        process.exit()
    })
    .catch(error => console.log(error))