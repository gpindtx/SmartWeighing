#!bin/bash
partitions=10
url="mongodb+srv://nunoleite:82QymHwOUd0jO5Yo@iot-production-jywab.mongodb.net/iot-production?retryWrites=true&w=majority"
file_path="data/weighings/weighings.json"
collection="weighings"

while [ "$1" != "" ]; do
    case $1 in
        -p | --partitions )     shift
                                partitions=$1
                                ;;
        -c | --collection )     shift
                                collection=$1
                                file_path="data/$collection/$collection.json"
                                ;;
        -u | --url )            shift
                                url=$1
                                ;;
        -f | --file_path )      shift
                                file_path=$1
                                ;;
        * )                     exit 1
    esac
    shift
done

for i in $(seq 1 $partitions); do
    node --max-old-space-size=8192 index.js extract --file_path $file_path --retrieve_partition $i --collection $collection;
done