const Weighing = require('../models/weighings');

module.exports.getPartition = async (skip, limit) => {
    const weighings = await Weighing.find({}).skip(skip).limit(limit).exec();
    return weighings;
}

module.exports.getAll = async () => {
    const weighings = await Weighing.find({}).exec();
    return weighings;
}

module.exports.count = async () => {
    const size = await Weighing.countDocuments().exec();
    return size;
}