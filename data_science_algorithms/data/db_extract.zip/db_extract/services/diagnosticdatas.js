const DiagnosticData = require('../models/diagnosticdatas');

module.exports.getPartition = async (skip, limit) => {
    const diagnosticdatas = await DiagnosticData.find({}).skip(skip).limit(limit).exec();
    return diagnosticdatas;
}

module.exports.getAll = async () => {
    const diagnosticdatas = await DiagnosticData.find({}).exec();
    return diagnosticdatas;
}

module.exports.count = async () => {
    const size = await DiagnosticData.countDocuments().exec();
    return size;
}