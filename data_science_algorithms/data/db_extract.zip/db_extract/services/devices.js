const Device = require('../models/devices');

module.exports.getPartition = async (skip, limit) => {
    const devices = await Device.find({}).skip(skip).limit(limit).exec();
    return devices;
}

module.exports.getAll = async () => {
    const devices = await Device.find({}).exec();
    return devices;
}

module.exports.count = async () => {
    const size = await Device.countDocuments().exec();
    return size;
}