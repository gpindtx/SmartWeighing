const DeviceInfo = require('../models/devicesinfos');

module.exports.getPartition = async (skip, limit) => {
    const devicesinfos = await DeviceInfo.find({}).skip(skip).limit(limit).exec();
    return devicesinfos;
}

module.exports.getAll = async () => {
    const devicesinfos = await DeviceInfo.find({}).exec();
    return devicesinfos;
}

module.exports.count = async () => {
    const size = await DeviceInfo.countDocuments().exec();
    return size;
}