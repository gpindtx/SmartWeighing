const Alarm = require('../models/alarms');

module.exports.getPartition = async (skip, limit) => {
    const alarms = await Alarm.find({}).skip(skip).limit(limit).exec();
    return alarms;
}

module.exports.getAll = async () => {
    const alarms = await Alarm.find({}).exec();
    return alarms;
}

module.exports.count = async () => {
    const size = await Alarm.countDocuments().exec();
    return size;
}