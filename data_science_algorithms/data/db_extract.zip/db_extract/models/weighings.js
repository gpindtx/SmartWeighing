const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const Weighing = new Schema({
    cellsArray: [
        {
            cellSerialNumber: String,
            cellWeight: Number
        }
    ],
    scaleStatus: String,
    scaleNet: Number,
    scaleGross: Number,
    scaleSerialNumber: String,
    scaleStatus: String,
    terminalRestartValue: String,
    terminalSerialNumber: String,
    timestamp: Number
})

module.exports = mongoose.model('Weighing', Weighing, 'weighingsdatas');