const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const DiagnosticData = new Schema({
    timestamp: Number,
    terminalSerialNumber: String,
    scaleSerialNumber: String,
    cellsArray: [
        {
            cellSerialNumber: String,
            cellPowerSupply: Number,
            cellTemperature: Number,
            cellInternalVolt: Number,
            cellDeadloadCount: Number
        }
    ]
});

module.exports = mongoose.model('DiagnosticData', DiagnosticData, 'diagnosticdatas');