const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const DeviceInfo = new Schema({
    scaleSerialNumber: String,
    terminalSerialNumber: String,
    cells: [
        {
            cellSerialNumber: String,
            cellId: Number,
            cellType: String,
            cellSoftwareId: String,
            cellAngularCoefficient: String,
            cellText: String
        }
    ],
    scaleCellCount: String,
    scaleCellsAngularCoefficient: {
        "@C1": String,
        "@C2": String,
        "@C3": String,
        "@C4": String,
        "@C5": String,
        "@C6": String,
        "@C7": String,
        "@C8": String,
    },
    scaleCellsSerialNumber: {
        "@C1": String,
        "@C2": String,
        "@C3": String,
        "@C4": String,
        "@C5": String,
        "@C6": String,
        "@C7": String,
        "@C8": String,
    },
    scaleDataAvailability: String,
    scaleId: Number,
    scaleSoftwareId: String,
    scaleText: String,
    scaleType: String,
    terminalSoftwareId: [String],
    terminalText: String,
    terminalType: String,
    timestamp: Number
});

module.exports = mongoose.model('DeviceInfo', DeviceInfo, 'devicesinfos');