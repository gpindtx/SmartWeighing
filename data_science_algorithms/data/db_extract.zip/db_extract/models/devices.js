const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const Device = new Schema({
    name: String,
    serialNumber: String,
    terminalModel: String,
    geoLat: Number,
    geoLng: Number,
    terminalSerialNumber: String,
    dimensions: String,
    maxCapacity: String,
    divisionSize: String,
    subsidiaryCompany: Schema.Types.ObjectId,
    dealerCompany: Schema.Types.ObjectId,
    customerCompany: Schema.Types.ObjectId
});

module.exports = mongoose.model('Device', Device, 'devices');