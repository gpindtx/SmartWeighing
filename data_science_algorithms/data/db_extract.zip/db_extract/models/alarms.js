const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const Alarm = new Schema({
    timestamp: Number,
    serialNumber: String,
    counter: Number,
    errorContext: String,
    errorCode: String,
    errorInfo: String,
    status: String
});

module.exports = mongoose.model('Alarm', Alarm, "alarms");